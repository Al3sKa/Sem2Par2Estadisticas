#pragma once

#ifndef OPERACIONES_H
#define OPERACIONES_H

class Operaciones
{
public:
	float Suma(float valor1, float valor2, float valor3);
	float Mayor(float valor1, float valor2, float valor3);
	float Menor(float valor1, float valor2, float valor3);
	float Multi(float valor1, float valor2, float valor3);
	float Prom(float valor1, float valor2, float valor3);
};

#endif /* OPERACIONES_H */